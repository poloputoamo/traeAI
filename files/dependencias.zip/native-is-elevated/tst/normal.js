const assert = require('assert');
const isElevated = require('..');

assert(isElevated() === false);
