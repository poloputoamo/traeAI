/*
 * 1DS JS SDK POST plugin, 3.2.13
 * Copyright (c) Microsoft and contributors. All rights reserved.
 * (Microsoft Internal Only)
 */
export {};//# sourceMappingURL=https://main.vscode-cdn.net/sourcemaps/cd4ee3b1c348a13bafd8f9ad8060705f6d4b9cba/node_modules/@microsoft/1ds-post-js/dist-esm/src/BatchNotificationActions.js.map